from setuptools import setup

setup(
    name='decorators',
    version='0.1',
    description='Decorate the function to enhance debugging and others.',
    author='Ponson Sun',
    author_email='ponsonsun@gmail.com',
    py_modules=['decorators']
)